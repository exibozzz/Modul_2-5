<?php

if($_GET["matematika"] == "Sabiranje"){echo $_GET["podatak_1"] + $_GET["podatak_2"];}

if($_GET["matematika"] == "Oduzimanje"){echo $_GET["podatak_1"] - $_GET["podatak_2"];}


?>
