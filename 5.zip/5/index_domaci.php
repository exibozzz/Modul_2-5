<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>#5 GET</title>
</head>
<body>
<holder class="form_holder">

<form class="forma" method="GET" action="baza_domaci.php">

        <input type="number" name="cena">
        <select name="vrsta">
            <option>Hrana</option>
            <option>Oprema za računare</option>
        </select>
        <input name="provera_poreza" type="checkbox" >
        <button>Izračunaj</button>

    </form>


</holder>
    
    
</body>
</html>