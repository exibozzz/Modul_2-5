<?php

$cena = $_GET["cena"];

$vrsta = $_GET["vrsta"];





$iznos_poreza = 0.10;

$dodatak_hrane = 50;

$dodatak_opreme = 350;

$cena_hrane = $cena+$dodatak_hrane;

$cena_opreme = $cena+$dodatak_opreme;

$porez_hrane = $cena_hrane*$iznos_poreza;

$porez_opreme = $cena_opreme*$iznos_poreza;

$total_cena_hrane = $cena_hrane+$porez_hrane;

$total_cena_opreme = $cena_opreme+$porez_opreme;

$provera_poreza = isset($_GET["provera_poreza"]);









//Cena bez poreza

if($vrsta == "Hrana"){echo "Cena bez pdv je $cena_hrane";}

if($vrsta == "Oprema za računare"){echo "Cena bez pdv je $cena_opreme";}




//Cena sa porezom

if($provera_poreza == "true" && $vrsta == "Hrana")  {echo "Vaša cena sa pdv iznosi $total_cena_hrane";}

if($provera_poreza == "true" && $vrsta == "Oprema za računare")  {echo "Vaša cena sa pdv iznosi $total_cena_opreme";}





 
//  $provera_poreza = isset($_GET["provera_poreza"]);

//  Ovo je ono sto mi je trebalo, pravio sam negde gresku nisam uspevao da napravim posebnu varijablu za isset vec sam je stavljao unutar if-a. 
//  Uglavnom sad lakše baratam sa varijantama kada je u checkbox u vidu booleana.









?>