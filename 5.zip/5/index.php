
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>#5 GET</title>
</head>
<body>


<form method="GET" action="baza.php"> 
    <input type="text" name="podatak_1">
    <input type="text" name="podatak_2">
    <select name="matematika">
             <option>Sabiranje</option>
             <option>Oduzimanje</option>
    </select>
    <button type>Izračunaj</button>
</form>

    
</body>
</html>